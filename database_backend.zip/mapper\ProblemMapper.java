package com.coding.platform.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.coding.platform.entity.Problem;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProblemMapper extends BaseMapper<Problem> {

}
